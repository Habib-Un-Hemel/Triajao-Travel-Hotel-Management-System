<?php
$con=mysqli_connect("localhost","root","","project_cse370");
if ($con->connect_error) {
    die("Connection failed: " . $con->connect_error);
}
else{

}
?>