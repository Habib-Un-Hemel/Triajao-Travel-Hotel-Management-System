<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="shortcut icon" href="https://i.ibb.co/nnLmmqM/505-5055502-simple-location-map-pin-icon3-red-free-vector-removebg-preview.png" type="image/x-icon">

    <title>Link with Icon</title>
</head>
<body>

<!-- Link with an icon -->
<a href="https://www.bkash.com/" target="_blank">
    <img src="1656234745bkash-app-logo-png.png"  width="50" height="50"> Pay First !!
</a>

</body>
</html>
