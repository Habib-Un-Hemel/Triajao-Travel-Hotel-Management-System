<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <form action="connect6.php" method="post">
        <div>
                <label for="name">Name</label>
                <input type="text" id="name" name="name">
        </div>
        <div class="">
                <label for="phone">Phone Number</label>
                <input type="text" id="phone " name="phone">
        </div>
        <div class="">
                <label for="nid">NID</label>
                <input type="text" id="nid" name="nid">
        </div>
        <div class="">
                <label for="ratings">Ratings</label>
                <input type="text" id="ratings" name="ratings">
        </div>
        <div class="">
                <label for="address">Address</label>
                <input type="text" id="address" name="address">
        </div>
        <div class="">
                <label for="city">City</label>
                <input type="text" id="city" name="city">
        </div>
        <input type="submit">
    </form>
</body>
</html>
